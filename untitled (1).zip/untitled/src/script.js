function greet() {
  alert("Hello! Thanks for visiting my website 🎉");
}
